﻿using System;

namespace WebServiceAutomationRestAPI.GetEndPoint
{
    internal class JsonConvert
    {
        internal static T DeserializeObject<T>(string responseContent)
        {
            throw new NotImplementedException();
        }
    }
}