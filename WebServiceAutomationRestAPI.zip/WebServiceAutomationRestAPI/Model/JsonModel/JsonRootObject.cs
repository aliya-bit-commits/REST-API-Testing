﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceAutomationRestAPI.Model.JsonModel
{
  public class JsonRootObject
    {
        //public class Data
        //{
            public int articleNumber { get; set; }
            public int region { get; set; }
            public bool isManualSent { get; set; }
            public string documentId { get; set; }
            public string uri { get; set; }
     //   }

        //public class Body
        //{
            public string id { get; set; }
            public string subject { get; set; }
   //         public Data data { get; set; }
            public string eventType { get; set; }
            public string dataVersion { get; set; }
            public string metadataVersion { get; set; }
            public DateTime eventTime { get; set; }
            public string topic { get; set; }
      //  }

        //public class Root
        //{
      //      public Body body { get; set; }
     //   }

 
    }
}
