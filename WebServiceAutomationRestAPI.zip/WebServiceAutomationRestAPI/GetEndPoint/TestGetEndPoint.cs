﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using Newtonsoft.Json;

namespace WebServiceAutomationRestAPI.GetEndPoint
{
    [TestClass]
    public class TestGetEndPoint
    {
        private string getUrl = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/86395";
        private string secureGetUrl = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/86395";
        // private bool jsonData;

        //   private string secureGetUrl = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/86395";

        public object HttpClientHelper { get; private set; }
        public object ResponseDataHelper { get; private set; }

        [TestMethod]
        public void TestGetAllEndPoint()
        {
            // Step 1. To create the HTTP client
            HttpClient httpClient = new HttpClient();
            // Step 2 &3 Create the request and execute it 
            httpClient.GetAsync(getUrl);
            // Close the connection
            httpClient.Dispose();

        }
        [TestMethod]
        public void TestGetAllEndPointWithUri()
        {
            // Step 1. To create the HTTP client
            HttpClient httpClient = new HttpClient();
            HttpRequestHeaders requestHeaders = httpClient.DefaultRequestHeaders;
            requestHeaders.Add("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");

            // Step 2 &3 Create the request and execute it
            Uri getUri = new Uri(getUrl);
            {
                try
                {
                    Task<HttpResponseMessage> httpResponse = httpClient.GetAsync(getUri);
                    HttpResponseMessage httpResponseMessage = httpResponse.Result;
                    Console.WriteLine(httpResponseMessage.ToString());

                    //Status Code
                    HttpStatusCode statusCode = httpResponseMessage.StatusCode;
                    Console.WriteLine("Status Code =>" + statusCode);
                    Console.WriteLine("Status Code =>" + (int)statusCode);

                    // Response Data 
                    HttpContent responseContent = httpResponseMessage.Content;
                    Task<string> responseData = responseContent.ReadAsStringAsync();
                    string data = responseData.Result;
                    Console.WriteLine(data);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }


            // Close the connection
            httpClient.Dispose();
        }
        
        [TestMethod]
        public void TestGetEndPointsUsingSendAsync()
        {
            HttpRequestMessage httpRequestMessage = new HttpRequestMessage();
            httpRequestMessage.RequestUri = new Uri(getUrl);
            httpRequestMessage.Method = HttpMethod.Get;
            httpRequestMessage.Headers.Add("Ocp-Apim-Subscription-Key","68f3c3e8a49d4bf0ac75ebf8522e348c");
            
            HttpClient httpClient = new HttpClient();
            Task<HttpResponseMessage> httpResponse = httpClient.SendAsync(httpRequestMessage);

            HttpResponseMessage httpResponseMessage = httpResponse.Result;
            Console.WriteLine(httpResponseMessage.ToString());

            //Status Code
            HttpStatusCode statusCode = httpResponseMessage.StatusCode;
            Console.WriteLine("Status Code =>" + statusCode);
            Console.WriteLine("Status Code =>" + (int)statusCode);

            // Response Data 
            HttpContent responseContent = httpResponseMessage.Content;
            Task<string> responseData = responseContent.ReadAsStringAsync();
            string data = responseData.Result;
            Console.WriteLine(data);
            httpClient.Dispose();
        }

        [TestMethod]
        public void TestGetEndpoint_Sync()
        {
          // HttpClientHelper.PerformGetRequest("https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/113270",null);

        }
        [TestMethod]
        public void TestGetAllEndPointInJsonFormat()
        {
            // Step 1. To create the HTTP client
            HttpClient httpClient = new HttpClient();
            HttpRequestHeaders requestHeaders= httpClient.DefaultRequestHeaders;
            requestHeaders.Add("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
        //    requestHeaders.Add("Primary-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
       //     requestHeaders.Add("Secondary-Key", "8ee0c0ef18784bcca5f11db99ab6dca7");

            // Step 2 & 3 Create the request and execute it
            {
                try
                {

            Task<HttpResponseMessage> httpResponse = httpClient.GetAsync(getUrl);
            HttpResponseMessage httpResponseMessage = httpResponse.Result;
            Console.WriteLine(httpResponseMessage.ToString());

            //Status Code 
            HttpStatusCode statusCode = httpResponseMessage.StatusCode;
            Console.WriteLine("Status Code =>" + statusCode);
           // Console.WriteLine("Status Code =>" + (int)statusCode);

            // Response Data 
            HttpContent responseContent = httpResponseMessage.Content;
            Task<string> responseData = responseContent.ReadAsStringAsync();
            string data = responseData.Result;
            Console.WriteLine(data);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
            // Close the connection
            httpClient.Dispose();
        }

        [TestMethod]
        public void TestUsingStatement()
            {
           using(HttpClient httpClient = new HttpClient())
                {
                // Step 2 & 3 Create the request and execute it
                {
                    try
                    {
                        using (HttpRequestMessage httpRequestMessage = new HttpRequestMessage())
                        {
                            httpRequestMessage.RequestUri = new Uri(getUrl);
                            httpRequestMessage.Method = HttpMethod.Get;
                            httpRequestMessage.Headers.Add("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
                            Task<HttpResponseMessage> httpResponse = httpClient.SendAsync(httpRequestMessage);

                            using (HttpResponseMessage httpResponseMessage = httpResponse.Result)
                            {
                                Console.WriteLine(httpResponseMessage.ToString());

                                //Status Code 
                                HttpStatusCode statusCode = httpResponseMessage.StatusCode;
                                //  Console.WriteLine("Status Code =>" + statusCode);
                                // Console.WriteLine("Status Code =>" + (int)statusCode);

                                // Response Data 
                                HttpContent responseContent = httpResponseMessage.Content;
                                Task<string> responseData = responseContent.ReadAsStringAsync();
                                string data = responseData.Result;
                                //   Console.WriteLine(data);

                                RestResponse1 restResponse = new RestResponse1((int)statusCode, responseData.Result);
                                Console.WriteLine(restResponse.ToString());

                      //       List<JsonRootObject> jsonRootObject = JsonConvert.DeserializeObject<List<JsonRootObject>>(restResponse.ResponseContent);
                     //          Console.WriteLine(jsonRootObject[0].ToString());

                                Assert.AreEqual(200, restResponse.StatusCode);
                              Assert.IsNotNull(restResponse.ResponseContent);
                           //     Assert.AreEqual(86395, jsonRootObject[0].ARTICLE_NUMBER);
                           ////     Assert.IsNotNull(jsonRootObject.ARTICLE_NUMBER);

                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }

                }
            }
        }
        /*public void TestSecureGetEndPoint()
        {
            Dictionary<string, string> httpHeader = new Dictionary<string, string>();
            httpHeader.Add("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
     
            RestResponse restResponse = HttpClientHelper.PerformGetRequest(secureGetUrl, httpHeader);
            //List < JsonRootObject > jsonData = ResponseDataHelper.DeserializeJsonResponse<List<JsonRootObject>>
            //    (restResponse.ResponseContent);

          

            Assert.AreEqual(200, restResponse.StatusCode);

            List<JsonRootObject> jsonData = ResponseDataHelper.DeserializeJsonResponse<List<JsonRootObject>>(restResponse.ResponseContent);

            Console.WriteLine(jsonData.ToString());

*/
        }
    }

    

