﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebServiceAutomationRestAPI.CustomReporter
{
    [TestClass]
    public class ReportInitialize
    {
        [AssemblyCleanup]
        public static void CleanUp()
        {
       //     CustomeExtentReporter.GetInstance().WriteToReport();

        }
    }
}
