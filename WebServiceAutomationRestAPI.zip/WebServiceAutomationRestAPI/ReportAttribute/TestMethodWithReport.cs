﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Glimpse.Mvc.Tab;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebServiceAutomationRestAPI.CustomReporter;
using ZendeskApi_v2.Models.Views;

namespace WebServiceAutomationRestAPI.ReportAttribute
{
/*
 * 1.Create a class which inherit from TestMethodAttribute
 * 2. Override the Execute mehtod to provide the implementation
 * 3. Use the custom attribute with testmethod 
 */
   public class TestMethodWithReport :TestMethodAttribute 
    {
        public override TestResult[] Execute(ITestMethod testMethod)
        {
            /* Implementation 
             */
            var name = testMethod.TestClassName + "." + testMethod.TestClassName;
            var result = base.Execute(testMethod);
            var outcome = result.FirstOrDefault();
            var status = Execution.Outcome;
            var errormsg = Execution?.TestFailureException?.Message;
            var trace = Execution?.TestFailureExcetption?.StackTrace;

            CustomeExtentReporter.GetInstance().AddToReport(name, "", status, errormsg + "\n" + trace);

            return result;
        }
    }
}
