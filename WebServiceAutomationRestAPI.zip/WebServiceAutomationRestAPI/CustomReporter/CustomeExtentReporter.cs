﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Nest;

namespace WebServiceAutomationRestAPI.CustomReporter
{
    //  Singleton Design Pattern
    public class CustomeExtentReporter
    {
        private readonly ExtentHtmlReporter extentHtmlReporter;

        internal void WriteToReport()
        {
            throw new NotImplementedException();
        }

        private readonly ExtentReports extentReports;
        private static CustomeExtentReporter customeExtentReporter;

        private CustomeExtentReporter()
        {
            extentHtmlReporter = new ExtentHtmlReporter(@"C:\Data\log\restsharp");
            extentReports = new ExtentReports();
            extentReports.AttachReporter(extentHtmlReporter);

        }
           public static CustomeExtentReporter GetInstance()
            {
                if (customeExtentReporter == null)
                {
                    customeExtentReporter = new CustomeExtentReporter();
                }
                return customeExtentReporter;

            }
            //public void AddToReport(string name, string description, UnitTestOutcome status, string error);
            //    {
                   // name
                   // description
                   // outcome
                   //   error info - in case of failure
                /* switch (Status)
                    {
                        case UnitTestOutcome.Passed:
                            extentReports.CreateTest(name, description).Pass("");
                            break;
                        case UnitTestOutcome.Failed:
                            extentReports.CreateTest(name, description).Fail(error);
                        default:
                            extentReports.CreateTest(name, description).Skip("");
                            break;

                    }
    }
                public void WriteToReport()
                {
                    extentReports?.Flush();
                }*/
            //*/
    }
}

