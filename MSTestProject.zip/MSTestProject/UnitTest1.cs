﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MSTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            Console.WriteLine("Automation Testing for RestAPI's");

            }
            [TestMethod]
            public void TestMethod2() // 2nd
            {
                Console.WriteLine("Test Method for Automation Testing");
            }

            [TestInitialize]
            public void Setup() // 1st ,4th
            {
                Console.WriteLine("This is Setup");

            }

            [TestCleanup]
            public void TearDown() //3rd ,6th
            {
            Console.WriteLine("This is Clean up");
            }
            public void ClassSetup(TestContext testContext)
            {
            Console.WriteLine("Class Set up");
            }
            public void ClassTearDown()
            {
            Console.WriteLine("Class TearDown");
            }
        [AssemblyInitialize]
        public static void AssemblySetup(TestContext testContext)
        {
            Console.WriteLine("Assembly Setup");
        }
        [AssemblyCleanup]
        public static void AssemblyTearDown (TestContext testContext)
        {
            Console.WriteLine("Assembly Tear Down");
        }
    }
    }

