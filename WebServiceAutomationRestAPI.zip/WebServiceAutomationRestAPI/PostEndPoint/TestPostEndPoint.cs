﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;

namespace WebServiceAutomationRestAPI.PostEndPoint
{
    [TestClass]
   public class TestPostEndPoint
    {
        private string postUrl = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/HandlePriceChange";
        private RestResponse restResponse;
        private string jsonMediaType = "application/json";
        private Random random = new Random();

        [TestMethod]
        public void TestPostEndpointWithJson()
        {

            //Method -POST 
            //Body alongwith 
            //Header - info 

            //int id = random.Next(1000);

            //string jsonData = "{" +

            //    "}";
            //using(HttpClient httpClient = new HttpClient())
            //{
            //    HttpContent httpContent = new StringContent(jsonData,Encoding.UTF8, jsonMediaType);
            //    Task<HttpResponseMessage> postResponse = httpClient.PostAsync(postUrl, httpContent);
            //    HttpStatusCode statusCode =postResponse.Result.StatusCode;
            //    HttpContent responseContent = postResponse.Result.Content;
            //    string responseData  = responseContent.ReadAsStringAsync().Result;

            //    restResponse = new RestResponse((int)statusCode, responseData);

            //    Assert.AreEqual(200, restResponse.StatusCode);
            //    Assert.IsNotNull(restResponse.ResponseContent, "Response Data is null/empty");
            //}
        }

    }
}
