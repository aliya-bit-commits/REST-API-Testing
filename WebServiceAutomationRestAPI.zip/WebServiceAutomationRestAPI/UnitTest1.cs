﻿using System;
using System.Net.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebServiceAutomationRestAPI
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            HttpClient httpClient = new HttpClient();

            string getUrl = "https://sbyccdeveis-apim-team.azure-api.net";



            httpClient.Dispose(); // Close the connection and release the resource
        }
    }
}
