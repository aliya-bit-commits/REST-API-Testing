﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using RestSharp;

//namespace WebServiceAutomationRestAPI.GetEndPoint
//{
//    private string uri = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/113270";
//    public class HttpWebRequest
//    {

//        var httpWebRequest = (HttpWebRequest)System.Net.WebRequest.Create(uri);
//        HttpWebRequest.ContentType = "application/json";
//        HttpWebRequest.Method = "GET"; // PUT, POST, DELETE, etc
//        httpWebRequest.ContentLength = 0; // sometimes you need to send zero (depending on API)
//        HttpWebResponse httpResponse = (HttpWebResponse)await httpWebRequest.GetResponseAsync();

//        private class ContentType
//        {
//        }
//    }
//        using (var streamReader = private new StreamReader(HttpResponse.GetResponseStream()))
//        {
//            var response = streamReader.ReadToEnd();
//             this is your code here...
//            var result = JsonConvert.DeserializeObject<UrlResponse>(response);
//            return result;
//    }
//}

    