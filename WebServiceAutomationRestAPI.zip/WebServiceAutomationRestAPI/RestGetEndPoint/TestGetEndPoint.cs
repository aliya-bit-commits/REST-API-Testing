﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;
using RestSharp.Authenticators;
using WebServiceAutomationRestAPI.GetEndPoint;

namespace WebServiceAutomationRestAPI.RestGetEndPoint
{
    [TestClass]
    public class TestGetEndPoint
    {
       private string getUrl = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/113270";
     private string secureGet = "https://sbyccdeveis-apim-team.azure-api.net/articles/v1/articles/113270";
       
        
        [TestMethod]
        public void TestGetUsingRestSharp()
        {
            IRestClient restClient = new RestClient();
            IRestRequest restRequest = new RestRequest(getUrl);
            restRequest.AddHeader("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
       //   restClient.Authenticator = new HttpBasicAuthenticator("Ocp-Apim-Subscription-Key", "be59d27f93f543b79c27b6cf5e8786d6");
            //restRequest.AddHeader(" ", "application/json");
            IRestResponse restResponse = restClient.Get(restRequest);
            restClient.Get(restRequest);
            Console.WriteLine(restResponse.IsSuccessful);
            Console.WriteLine(restResponse.StatusCode);
            Console.WriteLine(restResponse.ErrorMessage);
            Console.WriteLine(restResponse.ErrorException);
            if(restResponse.IsSuccessful)
            {
                Console.WriteLine("Status Code" + restResponse.StatusCode);
                Assert.AreEqual(200, (int)restResponse.StatusCode);
                Assert.AreEqual(200, (int)restResponse.StatusCode);
                Console.WriteLine("Response Content" + restResponse.Content);

            }

        }

        [TestMethod]
        public void TestSecureGet()
        {
            IRestClient client = new RestClient();
            client.Authenticator = new HttpBasicAuthenticator("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
            IRestRequest request = new RestRequest()
            {
                Resource = secureGet
            };
            IRestResponse response = client.Get(request);
            Assert.AreEqual(200, (int)response.StatusCode);
        }
        [TestMethod]
        public void TestGetWithJson_Deserialize()
        {
            IRestClient restClient = new RestClient();
            IRestRequest restRequest = new RestRequest(getUrl);
            //  restRequest.AddHeader("ContentType", "application/json");
            restRequest.AddHeader("Ocp-Apim-Subscription-Key", "68f3c3e8a49d4bf0ac75ebf8522e348c");
            IRestResponse<List<JsonRootObject>> restResponse= restClient.Get<List<JsonRootObject>>(restRequest);

            if(restResponse.IsSuccessful)
            {
                Console.WriteLine("Status Code " + restResponse.StatusCode);
                Assert.AreEqual(200, (int)restResponse.StatusCode);
                Console.WriteLine("Size of List " + restResponse.Data.Count);
                //List<JsonRootObject> Body = restResponse.Data;
                //JsonRootObject jsonRootObject = Body.Find((x) =>
                // {
                //     return x.id == 1;
                // });
            }
            else
            {
                Console.WriteLine("Error Message " + restResponse.ErrorMessage);
                Console.WriteLine("Stack Track " + restResponse.ErrorException);
            }
        }
    }
}
